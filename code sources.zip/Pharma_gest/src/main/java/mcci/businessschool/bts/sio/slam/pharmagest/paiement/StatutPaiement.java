package mcci.businessschool.bts.sio.slam.pharmagest.paiement;

public enum StatutPaiement {
    EN_ATTENTE,
    VALIDE,
    REJETE
}
