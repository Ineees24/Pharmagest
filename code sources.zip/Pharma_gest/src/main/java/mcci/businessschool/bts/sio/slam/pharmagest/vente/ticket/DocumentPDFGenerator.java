package mcci.businessschool.bts.sio.slam.pharmagest.vente.ticket;

import mcci.businessschool.bts.sio.slam.pharmagest.facture.Facture;
import mcci.businessschool.bts.sio.slam.pharmagest.facture.service.FactureService;
import mcci.businessschool.bts.sio.slam.pharmagest.patient.Patient;
import mcci.businessschool.bts.sio.slam.pharmagest.prescription.Prescription;
import mcci.businessschool.bts.sio.slam.pharmagest.vente.Vente;
import mcci.businessschool.bts.sio.slam.pharmagest.vente.ligne.LigneVente;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.FontMetrics;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.imageio.ImageIO;

/**
 * Classe unique pour la génération de documents PDF (tickets et factures)
 * Utilise exclusivement PDFBox pour la génération de PDF
 */
public class DocumentPDFGenerator {

    // Constantes
    private static final String RESOURCES_PATH = "src/main/resources/";
    private static final String LOGO_PATH = RESOURCES_PATH + "images/medicament.png";
    private static final Color HEADER_COLOR = new Color(41, 128, 185); // Bleu pharmaceutique
    private static final Color ACCENT_COLOR = new Color(46, 204, 113); // Vert médical
    private static final Color TABLE_HEADER_COLOR = new Color(240, 240, 240);
    private static final Color TABLE_ROW_ALT_COLOR = new Color(250, 250, 250);

    /**
     * Génère automatiquement un ticket PDF à partir d'une vente.
     * Le fichier sera enregistré dans le dossier "tickets/" sous le nom : ticket_vente_{ID}.pdf
     * Cette méthode ne crée PAS de facture.
     *
     * @param vente        La vente concernée
     * @param lignes       Les lignes de vente associées
     * @param patient      Le patient (si vente prescrite)
     * @param prescription La prescription (si vente prescrite)
     * @return Le fichier PDF généré ou null en cas d'erreur
     */
    public static File genererTicketPDF(Vente vente, List<LigneVente> lignes, Patient patient, Prescription prescription) {
        File fichierPDF = null;

        try {
            // ✅ 1. Créer le dossier "tickets" s'il n'existe pas
            File dossier = new File("tickets");
            if (!dossier.exists()) {
                dossier.mkdirs();
            }

            // ✅ 2. Construire le fichier de destination
            fichierPDF = new File(dossier, "ticket_vente_" + vente.getId() + ".pdf");

            // ✅ 3. Générer le PDF avec PDFBox
            try (PDDocument document = new PDDocument()) {
                // Format A6 pour un ticket (105 x 148 mm)
                PDPage page = new PDPage(PDRectangle.A6);
                document.addPage(page);

                try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
                    float margin = 20;
                    float yPosition = page.getMediaBox().getHeight() - margin;
                    float lineHeight = 12;
                    float width = page.getMediaBox().getWidth() - 2 * margin;

                    // Essayer d'ajouter le logo
                    try {
                        File logoFile = new File(LOGO_PATH);
                        if (logoFile.exists()) {
                            PDImageXObject logo = PDImageXObject.createFromFile(LOGO_PATH, document);
                            float logoWidth = 60;
                            float logoHeight = logoWidth * logo.getHeight() / logo.getWidth();
                            float centerX = (page.getMediaBox().getWidth() - logoWidth) / 2;
                            contentStream.drawImage(logo, centerX, yPosition - logoHeight, logoWidth, logoHeight);
                            yPosition -= logoHeight + 10;
                        }
                    } catch (IOException e) {
                        System.err.println("Impossible de charger le logo: " + e.getMessage());
                        // Continuer sans logo
                    }

                    // En-tête
                    drawCenteredText(contentStream, "PHARMACIE PHARMAGEST", page.getMediaBox().getWidth() / 2, yPosition, PDType1Font.HELVETICA_BOLD, 12);
                    yPosition -= lineHeight + 5;

                    drawLine(contentStream, margin, yPosition, page.getMediaBox().getWidth() - margin, yPosition);
                    yPosition -= lineHeight;

                    // Informations de la vente
                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA, 9);
                    contentStream.setLeading(lineHeight);
                    contentStream.newLineAtOffset(margin, yPosition);

                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
                    contentStream.showText("Date: " + dateFormat.format(vente.getDateVente()));
                    contentStream.newLine();

                    // Numéro de référence du ticket (pas de facture à ce stade)
                    contentStream.showText("Référence: TICKET-" + vente.getId());
                    contentStream.newLine();

                    contentStream.showText("Type: " + vente.getTypeVente().name());
                    contentStream.newLine();
                    contentStream.endText();

                    yPosition -= lineHeight * 3 + 5;
                    drawLine(contentStream, margin, yPosition, page.getMediaBox().getWidth() - margin, yPosition);
                    yPosition -= lineHeight;

                    // Titre des détails
                    drawCenteredText(contentStream, "DÉTAILS DES PRODUITS", page.getMediaBox().getWidth() / 2, yPosition, PDType1Font.HELVETICA_BOLD, 10);
                    yPosition -= lineHeight + 5;

                    // En-têtes du tableau
                    float[] columnWidths = {width * 0.5f, width * 0.15f, width * 0.15f, width * 0.2f};
                    float tableX = margin;

                    // Fond gris pour l'en-tête
                    contentStream.setNonStrokingColor(TABLE_HEADER_COLOR);
                    contentStream.addRect(tableX, yPosition - lineHeight, width, lineHeight);
                    contentStream.fill();
                    contentStream.setNonStrokingColor(0, 0, 0);

                    // Texte de l'en-tête
                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 8);
                    contentStream.newLineAtOffset(tableX + 2, yPosition - lineHeight + 3);
                    contentStream.showText("PRODUIT");
                    contentStream.endText();

                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 8);
                    contentStream.newLineAtOffset(tableX + columnWidths[0] + 2, yPosition - lineHeight + 3);
                    contentStream.showText("QTÉ");
                    contentStream.endText();

                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 8);
                    contentStream.newLineAtOffset(tableX + columnWidths[0] + columnWidths[1] + 2, yPosition - lineHeight + 3);
                    contentStream.showText("PRIX");
                    contentStream.endText();

                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 8);
                    contentStream.newLineAtOffset(tableX + columnWidths[0] + columnWidths[1] + columnWidths[2] + 2, yPosition - lineHeight + 3);
                    contentStream.showText("TOTAL");
                    contentStream.endText();

                    yPosition -= lineHeight;

                    // Lignes du tableau
                    for (int i = 0; i < lignes.size(); i++) {
                        LigneVente ligne = lignes.get(i);

                        // Alternance de couleurs pour les lignes
                        if (i % 2 == 1) {
                            contentStream.setNonStrokingColor(TABLE_ROW_ALT_COLOR);
                            contentStream.addRect(tableX, yPosition - lineHeight, width, lineHeight);
                            contentStream.fill();
                            contentStream.setNonStrokingColor(0, 0, 0);
                        }

                        String nom = ligne.getMedicament().getNom();
                        // Tronquer le nom s'il est trop long
                        if (nom.length() > 20) {
                            nom = nom.substring(0, 17) + "...";
                        }

                        int qte = ligne.getQuantiteVendu();
                        double prix = ligne.getPrixUnitaire();
                        double total = prix * qte;

                        contentStream.beginText();
                        contentStream.setFont(PDType1Font.HELVETICA, 8);
                        contentStream.newLineAtOffset(tableX + 2, yPosition - lineHeight + 3);
                        contentStream.showText(nom);
                        contentStream.endText();

                        contentStream.beginText();
                        contentStream.setFont(PDType1Font.HELVETICA, 8);
                        contentStream.newLineAtOffset(tableX + columnWidths[0] + 2, yPosition - lineHeight + 3);
                        contentStream.showText(String.valueOf(qte));
                        contentStream.endText();

                        contentStream.beginText();
                        contentStream.setFont(PDType1Font.HELVETICA, 8);
                        contentStream.newLineAtOffset(tableX + columnWidths[0] + columnWidths[1] + 2, yPosition - lineHeight + 3);
                        contentStream.showText(String.format("%.2f€", prix));
                        contentStream.endText();

                        contentStream.beginText();
                        contentStream.setFont(PDType1Font.HELVETICA, 8);
                        contentStream.newLineAtOffset(tableX + columnWidths[0] + columnWidths[1] + columnWidths[2] + 2, yPosition - lineHeight + 3);
                        contentStream.showText(String.format("%.2f€", total));
                        contentStream.endText();

                        yPosition -= lineHeight;
                    }

                    // Total
                    yPosition -= 5;
                    drawLine(contentStream, tableX, yPosition, tableX + width, yPosition);
                    yPosition -= lineHeight;

                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 10);
                    contentStream.newLineAtOffset(tableX + columnWidths[0] + columnWidths[1], yPosition - 5);
                    contentStream.showText("TOTAL:");
                    contentStream.endText();

                    String montantTotal = String.format("%.2f€", vente.getMontantTotal());
                    float montantWidth = PDType1Font.HELVETICA_BOLD.getStringWidth(montantTotal) / 1000 * 10;

                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 10);
                    // Positionner le montant à droite avec une marge de 10 points
                    contentStream.newLineAtOffset(tableX + columnWidths[0] + columnWidths[1] + columnWidths[2] + 2, yPosition - 5);
                    contentStream.showText(String.format("%.2f€", vente.getMontantTotal()));
                    contentStream.endText();

                    yPosition -= lineHeight + 10;

                    // Informations patient et prescription si vente prescrite
                    if (vente.getTypeVente().name().equals("PRESCRITE") && patient != null && prescription != null) {
                        contentStream.setNonStrokingColor(230, 255, 230); // Vert très clair
                        contentStream.addRect(margin, yPosition - lineHeight * 2, width, lineHeight * 2);
                        contentStream.fill();
                        contentStream.setNonStrokingColor(0, 0, 0);

                        contentStream.beginText();
                        contentStream.setFont(PDType1Font.HELVETICA_BOLD, 8);
                        contentStream.newLineAtOffset(margin + 5, yPosition - lineHeight + 3);
                        contentStream.showText("PATIENT: " + patient.getPrenom() + " " + patient.getNom());
                        contentStream.endText();

                        contentStream.beginText();
                        contentStream.setFont(PDType1Font.HELVETICA_BOLD, 8);
                        contentStream.newLineAtOffset(margin + 5, yPosition - lineHeight * 2 + 3);
                        contentStream.showText("MÉDECIN: " + prescription.getNomMedecin());
                        contentStream.endText();

                        yPosition -= lineHeight * 2 + 10;
                    }

                    // Message d'attente de paiement
                    contentStream.setNonStrokingColor(255, 240, 230); // Orange très clair
                    contentStream.addRect(margin, yPosition - lineHeight * 2, width, lineHeight * 2);
                    contentStream.fill();
                    contentStream.setNonStrokingColor(0, 0, 0);

                    drawCenteredText(contentStream, "EN ATTENTE DE PAIEMENT", page.getMediaBox().getWidth() / 2,
                            yPosition - lineHeight + 3, PDType1Font.HELVETICA_BOLD, 9);
                    drawCenteredText(contentStream, "Veuillez vous présenter à la caisse", page.getMediaBox().getWidth() / 2,
                            yPosition - lineHeight * 2 + 3, PDType1Font.HELVETICA, 8);

                    yPosition -= lineHeight * 3;

                    // Pied de page
                    drawCenteredText(contentStream, "Merci pour votre visite!", page.getMediaBox().getWidth() / 2, yPosition, PDType1Font.HELVETICA, 9);
                    yPosition -= lineHeight;
                    drawCenteredText(contentStream, "Conservez ce ticket pour tout échange.", page.getMediaBox().getWidth() / 2, yPosition, PDType1Font.HELVETICA, 8);
                }

                document.save(fichierPDF);
            }

            System.out.println("✅ Ticket PDF sauvegardé dans : " + fichierPDF.getAbsolutePath());
            return fichierPDF;

        } catch (Exception e) {
            System.err.println("❌ Erreur lors de la génération du ticket PDF : " + e.getMessage());
            e.printStackTrace();
        }

        return null;
    }

    /**
     * Génère une facture PDF pour une vente donnée et l'enregistre en base de données
     * @param vente La vente concernée
     * @param lignes Les lignes de vente
     * @param montantRecu Le montant reçu du client
     * @param factureService Service pour enregistrer la facture en base de données
     * @return Le fichier PDF généré ou null en cas d'erreur
     */
    public static File genererFacturePDF(Vente vente, List<LigneVente> lignes, double montantRecu, FactureService factureService) {
        try {
            // 1. Créer l'objet Facture si nécessaire
            Facture facture;
            if (vente.getFacture() == null) {
                // Générer un numéro de facture unique
                String numeroFacture = "FACT-" + vente.getId() + "-" + System.currentTimeMillis();
                facture = new Facture(new Date(), vente.getMontantTotal(), numeroFacture);

                // Enregistrer la facture en base de données
                Integer factureId = factureService.genererEtEnregistrerFacture(vente, facture);
                if (factureId == null) {
                    System.err.println("❌ Erreur lors de l'enregistrement de la facture en base de données");
                    return null;
                } else {
                    System.out.println("✅ Facture enregistrée en base avec l'ID: " + factureId);
                    // Vérifier que la facture est bien associée à la vente
                    facture.setId(factureId); // Assurez-vous que l'ID est défini dans l'objet facture
                }

                // Associer la facture à la vente
                vente.setFacture(facture);
            } else {
                facture = vente.getFacture();
            }

            // 2. Créer le dossier factures s'il n'existe pas
            File dossier = new File("factures");
            if (!dossier.exists()) {
                dossier.mkdirs();
            }

            // 3. Générer le fichier PDF
            File fichierPDF = new File(dossier, "facture_vente_" + vente.getId() + ".pdf");

            try (PDDocument document = new PDDocument()) {
                PDPage page = new PDPage(PDRectangle.A5);
                document.addPage(page);

                try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
                    float margin = 50;
                    float yPosition = page.getMediaBox().getHeight() - margin;
                    float lineHeight = 15;
                    float width = page.getMediaBox().getWidth() - 2 * margin;

                    // Essayer d'ajouter le logo
                    try {
                        File logoFile = new File(LOGO_PATH);
                        if (logoFile.exists()) {
                            PDImageXObject logo = PDImageXObject.createFromFile(LOGO_PATH, document);
                            float logoWidth = 80;
                            float logoHeight = logoWidth * logo.getHeight() / logo.getWidth();
                            float centerX = (page.getMediaBox().getWidth() - logoWidth) / 2;
                            contentStream.drawImage(logo, centerX, yPosition - logoHeight, logoWidth, logoHeight);
                            yPosition -= logoHeight + 15;
                        } else {
                            // Créer un logo de remplacement
                            PDImageXObject logo = createPlaceholderLogo(document, "PHARMAGEST");
                            float logoWidth = 150;
                            float logoHeight = logoWidth * logo.getHeight() / logo.getWidth();
                            float centerX = (page.getMediaBox().getWidth() - logoWidth) / 2;
                            contentStream.drawImage(logo, centerX, yPosition - logoHeight, logoWidth, logoHeight);
                            yPosition -= logoHeight + 15;
                        }
                    } catch (IOException e) {
                        System.err.println("Impossible de charger le logo: " + e.getMessage());
                        // Continuer sans logo
                    }

                    // En-tête
                    drawCenteredText(contentStream, "PHARMACIE PHARMAGEST", page.getMediaBox().getWidth() / 2, yPosition, PDType1Font.HELVETICA_BOLD, 16);
                    yPosition -= lineHeight + 5;
                    drawCenteredText(contentStream, "FACTURE", page.getMediaBox().getWidth() / 2, yPosition, PDType1Font.HELVETICA_BOLD, 14);
                    yPosition -= lineHeight * 2;

                    // Cadre pour les informations de la facture
                    contentStream.setNonStrokingColor(240, 240, 240); // Gris très clair
                    contentStream.addRect(margin, yPosition - lineHeight * 3, width, lineHeight * 3);
                    contentStream.fill();
                    contentStream.setNonStrokingColor(0, 0, 0); // Noir

                    // Bordure du cadre
                    contentStream.setStrokingColor(100, 100, 100);
                    contentStream.addRect(margin, yPosition - lineHeight * 3, width, lineHeight * 3);
                    contentStream.stroke();

                    // Informations de la facture
                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
                    contentStream.newLineAtOffset(margin + 10, yPosition - lineHeight + 3);
                    contentStream.showText("Facture N° : " + facture.getNumeroFacture());
                    contentStream.endText();

                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA, 10);
                    contentStream.newLineAtOffset(margin + 10, yPosition - lineHeight * 2 + 3);
                    contentStream.showText("Date émission : " + new SimpleDateFormat("dd/MM/yyyy").format(facture.getDateEmission()));
                    contentStream.endText();

                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA, 10);
                    contentStream.newLineAtOffset(margin + 10, yPosition - lineHeight * 3 + 3);
                    contentStream.showText("Type de vente : " + vente.getTypeVente().name());
                    contentStream.endText();

                    yPosition -= lineHeight * 4;

                    // Titre de la section médicaments
                    contentStream.setNonStrokingColor(200, 230, 255); // Bleu clair
                    contentStream.addRect(margin, yPosition - lineHeight, width, lineHeight);
                    contentStream.fill();
                    contentStream.setNonStrokingColor(0, 0, 0); // Noir

                    drawCenteredText(contentStream, "DÉTAILS DES MÉDICAMENTS", page.getMediaBox().getWidth() / 2, yPosition - lineHeight + 3, PDType1Font.HELVETICA_BOLD, 12);
                    yPosition -= lineHeight * 1.5f;

                    // En-têtes du tableau
                    float[] columnWidths = {width * 0.5f, width * 0.15f, width * 0.15f, width * 0.2f};
                    float tableX = margin;

                    // Fond gris pour l'en-tête
                    contentStream.setNonStrokingColor(TABLE_HEADER_COLOR);
                    contentStream.addRect(tableX, yPosition - lineHeight, width, lineHeight);
                    contentStream.fill();
                    contentStream.setNonStrokingColor(0, 0, 0);

                    // Bordure de l'en-tête
                    contentStream.setStrokingColor(100, 100, 100);
                    contentStream.addRect(tableX, yPosition - lineHeight, width, lineHeight);
                    contentStream.stroke();

                    // Texte de l'en-tête avec espacement approprié
                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 10);
                    contentStream.newLineAtOffset(tableX + 5, yPosition - lineHeight + 3);
                    contentStream.showText("Nom");
                    contentStream.endText();

                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 10);
                    contentStream.newLineAtOffset(tableX + columnWidths[0] + 5, yPosition - lineHeight + 3);
                    contentStream.showText("Qté");
                    contentStream.endText();

                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 10);
                    contentStream.newLineAtOffset(tableX + columnWidths[0] + columnWidths[1] + 5, yPosition - lineHeight + 3);
                    contentStream.showText("P.U.");
                    contentStream.endText();

                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 10);
                    contentStream.newLineAtOffset(tableX + columnWidths[0] + columnWidths[1] + columnWidths[2] + 5, yPosition - lineHeight + 3);
                    contentStream.showText("Total");
                    contentStream.endText();

                    yPosition -= lineHeight;

                    // Lignes du tableau avec alternance de couleurs et bordures
                    for (int i = 0; i < lignes.size(); i++) {
                        LigneVente ligne = lignes.get(i);

                        // Alternance de couleurs pour les lignes
                        if (i % 2 == 1) {
                            contentStream.setNonStrokingColor(TABLE_ROW_ALT_COLOR);
                            contentStream.addRect(tableX, yPosition - lineHeight, width, lineHeight);
                            contentStream.fill();
                            contentStream.setNonStrokingColor(0, 0, 0);
                        }

                        // Bordure de la ligne
                        contentStream.setStrokingColor(200, 200, 200);
                        contentStream.addRect(tableX, yPosition - lineHeight, width, lineHeight);
                        contentStream.stroke();

                        String nom = ligne.getMedicament().getNom();
                        // Tronquer le nom s'il est trop long
                        if (nom.length() > 25) {
                            nom = nom.substring(0, 22) + "...";
                        }

                        int qte = ligne.getQuantiteVendu();
                        double pu = ligne.getPrixUnitaire();
                        double sousTotal = qte * pu;

                        // Affichage des données avec espacement approprié
                        contentStream.beginText();
                        contentStream.setFont(PDType1Font.HELVETICA, 9);
                        contentStream.newLineAtOffset(tableX + 5, yPosition - lineHeight + 3);
                        contentStream.showText(nom);
                        contentStream.endText();

                        contentStream.beginText();
                        contentStream.setFont(PDType1Font.HELVETICA, 9);
                        contentStream.newLineAtOffset(tableX + columnWidths[0] + 5, yPosition - lineHeight + 3);
                        contentStream.showText(String.valueOf(qte));
                        contentStream.endText();

                        contentStream.beginText();
                        contentStream.setFont(PDType1Font.HELVETICA, 9);
                        contentStream.newLineAtOffset(tableX + columnWidths[0] + columnWidths[1] + 5, yPosition - lineHeight + 3);
                        contentStream.showText(String.format("%.2f€", pu));
                        contentStream.endText();

                        contentStream.beginText();
                        contentStream.setFont(PDType1Font.HELVETICA, 9);
                        contentStream.newLineAtOffset(tableX + columnWidths[0] + columnWidths[1] + columnWidths[2] + 5, yPosition - lineHeight + 3);
                        contentStream.showText(String.format("%.2f€", sousTotal));
                        contentStream.endText();

                        yPosition -= lineHeight;
                    }

                    // Total avec fond coloré et bordure
                    yPosition -= lineHeight;

                    // Créer un rectangle pour le total
                    contentStream.setNonStrokingColor(230, 230, 255); // Bleu très clair
                    contentStream.addRect(tableX, yPosition - lineHeight, width, lineHeight);
                    contentStream.fill();
                    contentStream.setNonStrokingColor(0, 0, 0);

                    // Bordure du rectangle
                    contentStream.setStrokingColor(100, 100, 100);
                    contentStream.addRect(tableX, yPosition - lineHeight, width, lineHeight);
                    contentStream.stroke();

                    // Texte "Total à régler" à gauche
                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 10);
                    contentStream.newLineAtOffset(tableX + 10, yPosition - lineHeight + 3);
                    contentStream.showText("Total à régler :");
                    contentStream.endText();

                    // Montant à droite
                    String montantTotal = String.format("%.2f€", vente.getMontantTotal());
                    float montantWidth = PDType1Font.HELVETICA_BOLD.getStringWidth(montantTotal) / 1000 * 10;

                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 10);
                    // Positionner le montant à droite avec une marge de 10 points
                    contentStream.newLineAtOffset(tableX + width - montantWidth - 10, yPosition - lineHeight + 3);
                    contentStream.showText(montantTotal);
                    contentStream.endText();

                    yPosition -= lineHeight * 2;

                    // Informations de paiement avec fond coloré et bordure
                    contentStream.setNonStrokingColor(240, 240, 240); // Gris très clair
                    contentStream.addRect(tableX, yPosition - lineHeight * 3, width, lineHeight * 3);
                    contentStream.fill();
                    contentStream.setNonStrokingColor(0, 0, 0);

                    contentStream.setStrokingColor(100, 100, 100);
                    contentStream.addRect(tableX, yPosition - lineHeight * 3, width, lineHeight * 3);
                    contentStream.stroke();

                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 10);
                    contentStream.newLineAtOffset(tableX + 5, yPosition - lineHeight + 3);
                    contentStream.showText("Montant total  : " + String.format("%.2f€", vente.getMontantTotal()));
                    contentStream.endText();

                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 10);
                    contentStream.newLineAtOffset(tableX + 5, yPosition - lineHeight * 2 + 3);
                    contentStream.showText("Montant reçu   : " + String.format("%.2f€", montantRecu));
                    contentStream.endText();

                    double monnaie = montantRecu - vente.getMontantTotal();
                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 10);
                    contentStream.newLineAtOffset(tableX + 5, yPosition - lineHeight * 3 + 3);
                    contentStream.showText("Monnaie rendue : " + String.format("%.2f€", monnaie));
                    contentStream.endText();

                    yPosition -= lineHeight * 4;

                    // Message de remerciement
                    drawCenteredText(contentStream, "Merci pour votre achat !", page.getMediaBox().getWidth() / 2, yPosition, PDType1Font.HELVETICA, 11);
                    yPosition -= lineHeight;
                    drawCenteredText(contentStream, "Conservez cette facture", page.getMediaBox().getWidth() / 2, yPosition, PDType1Font.HELVETICA, 9);
                }

                document.save(fichierPDF);
                System.out.println("✅ Facture PDF générée dans : " + fichierPDF.getAbsolutePath());
                return fichierPDF;

            } catch (IOException e) {
                System.err.println("Erreur génération facture PDF : " + e.getMessage());
                e.printStackTrace();
                return null;
            }
        } catch (Exception e) {
            System.err.println("Erreur lors de la génération de la facture : " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Dessine du texte centré
     */
    private static void drawCenteredText(PDPageContentStream contentStream, String text, float x, float y, PDFont font, float fontSize) throws IOException {
        float textWidth = font.getStringWidth(text) / 1000 * fontSize;
        contentStream.beginText();
        contentStream.setFont(font, fontSize);
        contentStream.setNonStrokingColor(0, 0, 0); // Noir
        contentStream.newLineAtOffset(x - textWidth / 2, y);
        contentStream.showText(text);
        contentStream.endText();
    }

    /**
     * Dessine une ligne
     */
    private static void drawLine(PDPageContentStream contentStream, float xStart, float yStart, float xEnd, float yEnd) throws IOException {
        contentStream.setStrokingColor(100, 100, 100);
        contentStream.setLineWidth(0.5f);
        contentStream.moveTo(xStart, yStart);
        contentStream.lineTo(xEnd, yStart);
        contentStream.stroke();
    }

    /**
     * Crée une image de logo de remplacement si le logo n'est pas trouvé
     */
    private static PDImageXObject createPlaceholderLogo(PDDocument document, String text) throws IOException {
        BufferedImage image = new BufferedImage(300, 100, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();

        // Fond blanc
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, 300, 100);

        // Bordure bleue
        g2d.setColor(new Color(0, 102, 204));
        g2d.drawRect(0, 0, 299, 99);

        // Texte centré
        g2d.setFont(new Font("Arial", Font.BOLD, 32));
        g2d.setColor(new Color(0, 102, 204));
        FontMetrics fm = g2d.getFontMetrics();
        int textWidth = fm.stringWidth(text);
        int textHeight = fm.getHeight();
        g2d.drawString(text, (300 - textWidth) / 2, (100 + textHeight / 2) / 2);

        // Ajouter un symbole de pharmacie
        g2d.setFont(new Font("Arial", Font.BOLD, 24));
        g2d.drawString("⚕", 10, 50);
        g2d.drawString("⚕", 275, 50);

        g2d.dispose();

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(image, "png", baos);

        return PDImageXObject.createFromByteArray(document, baos.toByteArray(), "Placeholder Logo");
    }

    private static PDFont getHelveticaFont() {
        return PDType1Font.HELVETICA;
    }
}
