package mcci.businessschool.bts.sio.slam.pharmagest.utilisateur;

public enum Role {
    PHARMACIEN,
    VENDEUR
}
