package mcci.businessschool.bts.sio.slam.pharmagest.vente.service;

import java.util.Date;
import java.util.List;

import mcci.businessschool.bts.sio.slam.pharmagest.facture.service.FactureService;
import mcci.businessschool.bts.sio.slam.pharmagest.medicament.Medicament;
import mcci.businessschool.bts.sio.slam.pharmagest.medicament.dao.MedicamentDao;
import mcci.businessschool.bts.sio.slam.pharmagest.medicament.service.MedicamentService;
import mcci.businessschool.bts.sio.slam.pharmagest.paiement.service.PaiementService;
import mcci.businessschool.bts.sio.slam.pharmagest.patient.Patient;
import mcci.businessschool.bts.sio.slam.pharmagest.patient.service.PatientService;
import mcci.businessschool.bts.sio.slam.pharmagest.prescription.Prescription;
import mcci.businessschool.bts.sio.slam.pharmagest.prescription.service.PrescriptionService;
import mcci.businessschool.bts.sio.slam.pharmagest.vente.TypeVente;
import mcci.businessschool.bts.sio.slam.pharmagest.vente.Vente;
import mcci.businessschool.bts.sio.slam.pharmagest.vente.ligne.LigneVente;

public class VenteIntegrationService {

    private VenteService venteService;
    private LigneVenteService ligneVenteService;
    private FactureService factureService;
    private PaiementService paiementService;
    private MedicamentService medicamentService;
    private PatientService patientService;
    private PrescriptionService prescriptionService;

    public VenteIntegrationService() throws Exception {
        venteService = new VenteService();
        ligneVenteService = new LigneVenteService();
        factureService = new FactureService();
        paiementService = new PaiementService();
        medicamentService = new MedicamentService();
        patientService = new PatientService();
        prescriptionService = new PrescriptionService();
    }

    /**
     * Création de la vente par le pharmacien.
     * Si la vente est prescrite, on enregistre d'abord le patient et la prescription.
     * Ensuite, la vente est enregistrée normalement.
     * Cette méthode ne génère PAS de facture, seulement un ticket.
     *
     * @param lignes       La liste des lignes de vente sélectionnées.
     * @param type         Le type de vente (LIBRE ou PRESCRITE).
     * @param patient      Les informations du patient (si vente prescrite).
     * @param prescription Les informations de la prescription (si vente prescrite).
     * @return L'objet Vente créé.
     */
    public Vente creerVentePharmacien(List<LigneVente> lignes, TypeVente type, Patient patient, Prescription prescription) {
        // Calcul du montant total de la vente
        double montantTotal = lignes.stream()
                .mapToDouble(ligne -> ligne.getQuantiteVendu() * ligne.getPrixUnitaire())
                .sum();

        // Déclaration des variables pour stocker l'ID du patient et de la prescription
        Integer prescriptionId = null;

        // Gestion de la vente prescrite
        if (type == TypeVente.PRESCRITE) {
            if (patient == null || prescription == null) {
                throw new IllegalArgumentException("⚠️ Erreur : Les informations du patient et de la prescription sont requises pour une vente prescrite.");
            }

            try {
                // 1️⃣ Enregistrer le patient et récupérer son ID
                Integer patientId = patientService.ajouterPatient(patient);
                if (patientId == null) {
                    throw new RuntimeException("❌ Erreur lors de l'ajout du patient !");
                }
                System.out.println("✅ Patient ajouté avec succès - ID : " + patientId);

                // 2️⃣ Enregistrer la prescription associée au patient
                prescriptionId = prescriptionService.ajouterPrescription(prescription, patientId);
                if (prescriptionId == null) {
                    throw new RuntimeException("❌ Erreur lors de l'ajout de la prescription !");
                }
                System.out.println("✅ Prescription ajoutée avec succès - ID : " + prescriptionId);

            } catch (Exception e) {
                throw new RuntimeException("❌ Erreur lors de l'ajout du patient ou de la prescription : " + e.getMessage());
            }
        }

        // Création de l'objet Vente
        Vente vente = new Vente(new Date(), montantTotal, type, null);
        if (prescriptionId != null) {
            vente.setPrescriptionId(prescriptionId);
        }

        // Insérer la vente dans la base et récupérer son ID
        Integer idVente = venteService.ajouterVente(vente);
        if (idVente == null || idVente <= 0) {
            throw new RuntimeException("❌ L'ajout de la vente a échoué !");
        }
        vente.setId(idVente);
        System.out.println("✅ Vente ajoutée avec succès - ID : " + idVente);

        // Affecter l'ID de la vente à chaque LigneVente et les insérer
        for (LigneVente ligne : lignes) {
            ligne.setVenteId(idVente);
            ligneVenteService.ajouterLigneVente(ligne);
        }

        System.out.println("✅ Vente créée avec ID : " + idVente + " | En attente de paiement");

        return vente;
    }

    public Vente creerVentePharmacien(List<LigneVente> lignes, TypeVente type) {
        return creerVentePharmacien(lignes, type, null, null);
    }


}
