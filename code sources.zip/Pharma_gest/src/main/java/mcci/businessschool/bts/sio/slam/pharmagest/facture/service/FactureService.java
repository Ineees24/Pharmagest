package mcci.businessschool.bts.sio.slam.pharmagest.facture.service;

import mcci.businessschool.bts.sio.slam.pharmagest.facture.Facture;
import mcci.businessschool.bts.sio.slam.pharmagest.facture.dao.FactureDao;
import mcci.businessschool.bts.sio.slam.pharmagest.vente.Vente;

public class FactureService {
    private FactureDao factureDao;

    public FactureService() throws Exception {
        this.factureDao = new FactureDao();
    }

    public Integer genererEtEnregistrerFacture(Vente vente, Facture facture) {
        try {
            System.out.println("🔄 Tentative d'enregistrement de la facture pour la vente ID: " + vente.getId());
            Integer factureId = factureDao.ajouterFacture(facture, vente);
            if (factureId != null) {
                System.out.println("✅ Facture enregistrée avec succès, ID: " + factureId);
                // Mettre à jour l'objet facture avec l'ID généré
                facture.setId(factureId);
                // Mettre à jour la vente avec la facture
                vente.setFacture(facture);
            } else {
                System.err.println("❌ Échec de l'enregistrement de la facture: aucun ID retourné");
            }
            return factureId;
        } catch (Exception e) {
            System.err.println("❌ Erreur lors de la génération de la facture : " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
}
