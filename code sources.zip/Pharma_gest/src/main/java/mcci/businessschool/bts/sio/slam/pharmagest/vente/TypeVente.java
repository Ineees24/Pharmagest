package mcci.businessschool.bts.sio.slam.pharmagest.vente;

public enum TypeVente {
    LIBRE,
    PRESCRITE
}
